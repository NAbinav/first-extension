const targetUrl = 'https://www.youtube.com/watch?v=dQw4w9WgXcQ&pp=ygUIcmlja3JvbGw%3D'; // Replace with your desired URL

if (window.location.href !== targetUrl) {
  window.location.href = targetUrl;
}
